import Notification from "../utils/index";

type NotificationCardProps<T extends Notification> = {
  data: T;
};

function NotificationCard<T extends Notification>({
  data,
}: NotificationCardProps<T>) {
  switch (data.type) {
    case "success":
      return (
        <div style={{ backgroundColor: "lightgreen" }}>{data.message}</div>
      );

    case "error":
      return (
        <div style={{ backgroundColor: "lightcoral" }}>
          {data.message} (Error code: {data.errorCode})
        </div>
      );

    case "warning":
      return <div style={{ backgroundColor: "brown" }}>{data.message}</div>;

    default:
      return <div>Unknown notification type</div>;
  }
}

export default NotificationCard;
