import NotificationCard from "./components/NotificationCard";

function App() {
  return (
    <div>
      <NotificationCard
        data={{
          type: "success",
          message: "Data saved successfully!",
        }}
      />

      <NotificationCard
        data={{
          type: "error",
          message: "Failed to load data",
          errorCode: 500,
        }}
      />

      <NotificationCard
        data={{
          type: "warning",
          message: "Connection is unstable",
        }}
      />
    </div>
  );
}

export default App;
