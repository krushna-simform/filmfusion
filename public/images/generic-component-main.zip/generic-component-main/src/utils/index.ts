type SuccessNotification = {
  type: "success";
  message: string;
};

type ErrorNotification = {
  type: "error";
  message: string;
  errorCode: number;
};

type WarningNotification = {
  type: "warning";
  message: string;
};

type Notification =
  | SuccessNotification
  | ErrorNotification
  | WarningNotification;

export default Notification;
